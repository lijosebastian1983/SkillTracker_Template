import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {RouterModule, Routes} from '@angular/router';  
import { AppComponent } from './app.component';
import { AddEditSkillsComponent } from './views/add-edit-skills/add-edit-skills.component';
import { AddEditAssociatesComponent } from './views/add-edit-associates/add-edit-associates.component';
import { DashboardComponent } from './Views/dashboard/dashboard.component';
import { AppRoutingModule } from './app-routing-module/app-routing-module';
@NgModule({
  declarations: [
    AppComponent,
    AddEditSkillsComponent,
    AddEditAssociatesComponent,
    DashboardComponent,    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
