import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-edit-associates',
  templateUrl: './add-edit-associates.component.html',
  styleUrls: ['./add-edit-associates.component.css']
})
export class AddEditAssociatesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
