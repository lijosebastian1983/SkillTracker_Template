import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-edit-skills',
  templateUrl: './add-edit-skills.component.html',
  styleUrls: ['./add-edit-skills.component.css']
})
export class AddEditSkillsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
